import { Component, OnInit, Input} from '@angular/core';
import { ContractTemplate } from '../../interfaces/contract-template';

@Component({
  selector: 'app-card-template',
  templateUrl: './card-template.component.html',
  styleUrls: ['./card-template.component.css']
})
export class CardTemplateComponent implements OnInit {
  @Input() public template : ContractTemplate;
  public conditions : Array<string>;
  constructor() { }

  ngOnInit() {
    // console.log(this.template);
    this.conditions = this.template[0].conditions;
  }

}
